package Frames;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;
import Entities.MenuItem;
public class Homepage extends JFrame implements MouseListener,ActionListener {
	private JPanel panel,sidepanel,inputpanel,outputpanel,orderform,recordform;
	private JLabel sectionlbl;
	private JTextField namefld,phonefld,quantityfld,pricefld,searchfld,recordfld;
	private JComboBox tablebox,timebox,itembox;
	private JTextArea outputarea;
	private JButton orderbtn,menubtn,orderitembtn,logoutbtn;
	private JButton addbtn,updatebtn,deletebtn,searchbtn,clearbtn,savebtn,loadbtn,clearoutputbtn;
	private Login f1;
	private String username;
	private String data[][]=new String[2][100];
	private int count[]={0,0};
	private String table[]=new String[100];
	private Order order[]=new Order[200];
	private int tabletotal,total,nextid=1,current=0,selected=-1,found=-1;
	private Color navy=new Color(16,45,82),gold=new Color(220,166,49),cream=new Color(255,253,247),blue=new Color(25,118,210),green=new Color(46,139,87),red=new Color(211,47,47);
	public Homepage(String username,Login f1) {
		super("Restaurant Management System");
		this.setSize(1280,720);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.f1=f1;
		this.username=username;
		loadData();
		panel=makePanel(null,0,0,1280,720,new Color(250,246,235));
		sidepanel=makePanel(panel,0,0,200,720,navy);
		makeLabel(panel,"Restaurant Management System",230,15,650,45,30);
		makeLabel(panel,"User: "+username,900,20,170,35,17);
		orderbtn=makeButton(sidepanel,"Customer Orders",15,95,170,42);
		menubtn=makeButton(sidepanel,"Menu Items",15,155,170,42);
		orderitembtn=makeButton(sidepanel,"Order Items",15,215,170,42);
		logoutbtn=makeButton(panel,"Logout",1100,20,100,35);
		inputpanel=makePanel(panel,220,70,490,590,cream);
		inputpanel.setBorder(BorderFactory.createLineBorder(gold));
		sectionlbl=makeLabel(inputpanel,"",20,10,450,30,20);
		orderform=makePanel(inputpanel,0,42,490,350,cream);
		namefld=makeField(orderform,"Customer Name",20,5);
		phonefld=makeField(orderform,"Phone",255,5);
		tablebox=makeCombo(orderform,"Table Number",20,72);
		timebox=makeCombo(orderform,"Order Time",255,72);
		String time[]={"12:00 PM","02:00 PM","06:00 PM","07:00 PM","08:00 PM","09:00 PM"};
		for(int i=0;i<time.length;i++) timebox.addItem(time[i]);
		itembox=makeCombo(orderform,"Menu Item",20,139);
		quantityfld=makeField(orderform,"Quantity",255,139);
		pricefld=makeField(orderform,"Unit Price",20,206);
		pricefld.setEditable(false);
		searchfld=makeField(orderform,"Search ID, Name, Table or Item",20,273);
		searchfld.setBounds(20,294,300,30);
		searchbtn=makeButton(orderform,"Search",340,294,125,30);
		itembox.addActionListener(this);
		recordform=makePanel(inputpanel,0,42,490,350,cream);
		recordfld=makeField(recordform,"Record",20,110);
		recordfld.setBounds(20,145,445,35);
		addbtn=makeButton(inputpanel,"Add",20,430,140,40);
		updatebtn=makeButton(inputpanel,"Update",175,430,140,40);
		deletebtn=makeButton(inputpanel,"Delete",330,430,140,40);
		clearbtn=makeButton(inputpanel,"Clear Form",175,490,140,38);
		outputpanel=makePanel(panel,730,70,530,590,cream);
		outputpanel.setBorder(BorderFactory.createLineBorder(gold));
		makeLabel(outputpanel,"Output",20,10,490,30,20);
		outputarea=new JTextArea();
		outputarea.setFont(new Font("Monospaced",Font.PLAIN,14));
		outputarea.setForeground(navy);
		outputarea.setEditable(false);
		outputarea.addMouseListener(this);
		JScrollPane scroll=new JScrollPane(outputarea);
		scroll.setBounds(20,45,490,455);
		scroll.setBorder(BorderFactory.createLineBorder(gold));
		outputpanel.add(scroll);
		savebtn=makeButton(outputpanel,"Save Data",20,525,150,38);
		loadbtn=makeButton(outputpanel,"Load Data",190,525,150,38);
		clearoutputbtn=makeButton(outputpanel,"Clear Output",360,525,150,38);
		refreshCombo();
		showSection();
		Image image=new ImageIcon("./Images/pr2.jpeg").getImage().getScaledInstance(1280,720,Image.SCALE_SMOOTH);
		JLabel imglbl=new JLabel(new ImageIcon(image));
		imglbl.setBounds(0,0,1280,720);
		panel.add(imglbl);
		this.add(panel);
	}
	private JPanel makePanel(JPanel owner,int x,int y,int width,int height,Color color) {
		JPanel value=new JPanel();
		value.setLayout(null);
		value.setBounds(x,y,width,height);
		value.setBackground(color);
		if(owner!=null) owner.add(value);
		return value;
	}
	private JLabel makeLabel(JPanel owner,String text,int x,int y,int width,int height,int size) {
		JLabel value=new JLabel(text);
		value.setBounds(x,y,width,height);
		value.setFont(new Font("Cambria",Font.BOLD,size));
		value.setForeground(navy);
		owner.add(value);
		return value;
	}
	private JTextField makeField(JPanel owner,String text,int x,int y) {
		makeLabel(owner,text,x,y,215,18,13);
		JTextField value=new JTextField();
		value.setBounds(x,y+21,210,30);
		value.setFont(new Font("Cambria",Font.PLAIN,14));
		value.setBorder(BorderFactory.createLineBorder(gold));
		owner.add(value);
		return value;
	}
	private JComboBox makeCombo(JPanel owner,String text,int x,int y) {
		makeLabel(owner,text,x,y,215,18,13);
		JComboBox value=new JComboBox();
		value.setBounds(x,y+21,210,30);
		value.setFont(new Font("Cambria",Font.PLAIN,14));
		value.setBackground(cream);
		owner.add(value);
		return value;
	}
	private JButton makeButton(JPanel owner,String text,int x,int y,int width,int height) {
		JButton value=new JButton(text);
		value.setBounds(x,y,width,height);
		value.setFont(new Font("Cambria",Font.BOLD,14));
		value.setFocusPainted(false);
		value.addMouseListener(this);
		value.addActionListener(this);
		owner.add(value);
		normalButton(value);
		return value;
	}
	private void normalButton(JButton value) {
		String text=value.getText();
		boolean page=(current==0&&text.equals("Customer Orders"))||(current==1&&text.equals("Menu Items"))||(current==2&&text.equals("Order Items"));
		Color background=text.equals("Add")?blue:text.equals("Update")?green:text.equals("Delete")?red:navy;
		if(text.equals("Save Data")||page) background=gold;
		if(text.equals("Clear Form")||text.equals("Clear Output")||text.equals("Logout")) background=cream;
		Color foreground=background==cream||background==gold?navy:Color.WHITE;
		value.setBackground(background);
		value.setForeground(foreground);
		value.setBorder(BorderFactory.createLineBorder(background));
	}
	private void loadData() {
		tabletotal=new Table().getTable(table);
		count[0]=new MenuItem().getMenuItem(data[0]);
		count[1]=new OrderItem().getOrderItem(data[1]);
		total=new Order().getOrder(order);
		nextid=1;
		for(int i=0;i<total;i++) {
			try {
				int id=Integer.parseInt(order[i].getOid());
				if(id>=nextid)
					nextid=id+1;
			} catch(Exception e) {}
		}
		if(itembox!=null)
			refreshCombo();
	}
	private void refreshCombo() {
		tablebox.removeAllItems();
		itembox.removeAllItems();
		for(int i=0;i<tabletotal;i++) tablebox.addItem(table[i]);
		for(int i=0;i<count[0];i++) {
			String value[]=data[0][i].split("\t");
			if(value.length==2)
				itembox.addItem(value[0]);
		}
		showPrice();
	}
	private void showSection() {
		selected=-1;
		found=-1;
		orderform.setVisible(current==0);
		recordform.setVisible(current!=0);
		clearbtn.setVisible(current==0);
		if(current==0) {
			sectionlbl.setText("Customer Orders");
			clearField();
		} else {
			sectionlbl.setText(current==1?"Menu Items - Name, Price":"Order Items - Name, Quantity, Unit Price");
			recordfld.setText("");
			showRecord();
		}
		JButton navigation[]={orderbtn,menubtn,orderitembtn};
		for(int i=0;i<navigation.length;i++) normalButton(navigation[i]);
	}
	private void showRecord() {
		int index=current-1;
		String text=count[index]==0?"No records saved yet.\n":"";
		for(int i=0;i<count[index];i++) text=text+(i+1)+". "+data[index][i].replace("\t"," | ")+"\n";
		outputarea.setText(text);
	}
	private String getRecord() {
		String value[]=recordfld.getText().trim().split(",");
		if(current==1&&value.length==2)
			return value[0].trim()+"\t"+value[1].trim();
		if(current==2&&value.length==3)
			return value[0].trim()+"\t"+value[1].trim()+"\t"+value[2].trim();
		return "";
	}
	private boolean hasError(boolean value,String message) {
		if(value) JOptionPane.showMessageDialog(this,message);
		return value;
	}
	private void changeRecord(int task) {
		int index=current-1;
		String record=getRecord();
		if(hasError(task!=3&&record.isEmpty(),"Enter the record in the shown format"))
			return;
		if(hasError(task!=1&&selected<0,"Select a record first"))
			return;
		if(hasError(task==1&&count[index]>=100,"Record limit reached"))
			return;
		if(task==1) {
			for(int i=0;i<count[index];i++) {
				if(hasError(data[index][i].equals(record),"This record already exists"))
					return;
			}
			data[index][count[index]]=record;
			count[index]++;
		} else if(task==2)
			data[index][selected]=record;
		else {
			for(int i=selected;i<count[index]-1;i++) data[index][i]=data[index][i+1];
			count[index]--;
		}
		saveData();
		loadData();
		recordfld.setText("");
		selected=-1;
		showRecord();
	}
	private void saveData() {
		new MenuItem().saveMenuItem(data[0],count[0]);
		new OrderItem().saveOrderItem(data[1],count[1]);
		new Order().saveOrder(order,total);
	}
	private void showPrice() {
		pricefld.setText("");
		if(itembox.getSelectedItem()!=null) {
			for(int i=0;i<count[0];i++) {
				String value[]=data[0][i].split("\t");
				if(value.length==2&&value[0].equals(itembox.getSelectedItem().toString()))
					pricefld.setText(value[1]);
			}
		}
	}
	private Order getForm(String id) {
		if(hasError(namefld.getText().isEmpty()||phonefld.getText().isEmpty()||quantityfld.getText().isEmpty(),"Fill up Customer Name, Phone and Quantity"))
			return null;
		if(hasError(tablebox.getSelectedItem()==null||itembox.getSelectedItem()==null,"Menu Item and Table data are required"))
			return null;
		try {
			int quantity=Integer.parseInt(quantityfld.getText());
			if(quantity<=0)
				throw new Exception();
			double price=Double.parseDouble(pricefld.getText());
			OrderItem item=new OrderItem(itembox.getSelectedItem().toString(),quantityfld.getText(),pricefld.getText(),String.format("%.2f",price*quantity));
			return new Order(id,namefld.getText(),phonefld.getText(),tablebox.getSelectedItem().toString(),timebox.getSelectedItem().toString(),username,item);
		} catch(Exception e) {
			JOptionPane.showMessageDialog(this,"Quantity or Menu Price is not valid");
			return null;
		}
	}
	private void changeOrder(int task) {
		if(hasError(task==1&&total>=200,"Order limit reached"))
			return;
		if(hasError(task!=1&&selected<0,"Select an order first"))
			return;
		if(task==3) {
			for(int i=selected;i<total-1;i++)
				order[i]=order[i+1];
			total--;
			new Order().saveOrder(order,total);
		} else {
			String id=task==1?String.valueOf(nextid):order[selected].getOid();
			Order value=getForm(id);
			if(value==null)
				return;
			if(task==1) {
				order[total]=value;
				total++;
				nextid++;
				value.addOrder();
			} else {
				order[selected]=value;
				new Order().saveOrder(order,total);
			}
		}
		clearField();
		JOptionPane.showMessageDialog(this,task==1?"Order Added":task==2?"Order Updated":"Order Deleted");
	}
	private void clearField() {
		JTextField field[]={namefld,phonefld,quantityfld,searchfld};
		for(int i=0;i<field.length;i++) field[i].setText("");
		if(tablebox.getItemCount()>0)
			tablebox.setSelectedIndex(0);
		if(itembox.getItemCount()>0)
			itembox.setSelectedIndex(0);
		timebox.setSelectedItem("07:00 PM");
		selected=-1;
		found=-1;
		showPrice();
		showOrder();
	}
	private String getLine(Order value) {return value.getOid()+" | "+value.getCname()+" | "+value.getOitem().getIname()+" x"+value.getOitem().getIquantity()+" | "+value.getTnumber()+" | Total: "+value.getOitem().getItotal()+"\n";}
	private void showOrder() {
		String text=total==0?"No orders saved yet.\n":"";
		for(int i=0;i<total;i++) text=text+getLine(order[i]);
		outputarea.setText(text);
	}
	private void searchOrder() {
		String key=searchfld.getText().trim().toLowerCase();
		if(hasError(key.isEmpty(),"Enter Order ID, Customer Name, Table or Menu Item"))
			return;
		for(int i=0;i<total;i++) {
			Order value=order[i];
			if(value.getOid().equals(key)||value.getCname().toLowerCase().contains(key)||value.getTnumber().toLowerCase().contains(key)||value.getOitem().getIname().toLowerCase().contains(key)) {
				selected=i;
				found=i;
				loadForm(value);
				outputarea.setText(getLine(value));
				return;
			}
		}
		showOrder();
		JOptionPane.showMessageDialog(this,"Order Not Found");
	}
	private void loadForm(Order value) {
		namefld.setText(value.getCname());
		phonefld.setText(value.getPhone());
		tablebox.setSelectedItem(value.getTnumber());
		timebox.setSelectedItem(value.getOtime());
		itembox.setSelectedItem(value.getOitem().getIname());
		quantityfld.setText(value.getOitem().getIquantity());
		pricefld.setText(value.getOitem().getIprice());
	}
	public void actionPerformed(ActionEvent ae) {
		Object source=ae.getSource();
		if(source==orderbtn||source==menubtn||source==orderitembtn) {
			current=source==orderbtn?0:source==menubtn?1:2;
			showSection();
			return;
		}
		if(source==addbtn||source==updatebtn||source==deletebtn) {
			int task=source==addbtn?1:source==updatebtn?2:3;
			if(current==0)
				changeOrder(task);
			else
				changeRecord(task);
		} else if(source==searchbtn)
			searchOrder();
		else if(source==clearbtn)
			clearField();
		else if(source==savebtn) {
			saveData();
			JOptionPane.showMessageDialog(this,"Application Data Saved");
		} else if(source==loadbtn) {
			loadData();
			showSection();
		} else if(source==clearoutputbtn)
			outputarea.setText("");
		else if(source==itembox)
			showPrice();
		else if(source==logoutbtn) {
			this.setVisible(false);
			f1.setVisible(true);
		}
	}
	public void mouseClicked(MouseEvent me) {
		if(me.getSource()!=outputarea||outputarea.getText().isEmpty())
			return;
		try {
			int line=outputarea.getLineOfOffset(outputarea.getCaretPosition());
			if(current==0) {
				selected=found>=0?found:line;
				if(selected<total) loadForm(order[selected]);
			} else if(line<count[current-1]) {
				selected=line;
				recordfld.setText(data[current-1][line].replace("\t",","));
			}
		} catch(Exception e) {
		}
	}
	private void mouseColor(JButton value,boolean press) {
		String text=value.getText();
		Color color=press?navy:new Color(235,178,55);
		if(text.equals("Add")) color=press?new Color(16,92,170):new Color(66,145,225);
		if(text.equals("Update")) color=press?new Color(34,112,70):new Color(66,160,105);
		if(text.equals("Delete")) color=press?new Color(175,35,35):new Color(225,75,75);
		value.setBackground(color);
		value.setForeground(press?Color.WHITE:navy);
		if(text.equals("Add")||text.equals("Update")||text.equals("Delete")) value.setForeground(Color.WHITE);
	}
	public void mouseEntered(MouseEvent me) {if(me.getSource() instanceof JButton) mouseColor((JButton)me.getSource(),false);}
	public void mouseExited(MouseEvent me) {if(me.getSource() instanceof JButton) normalButton((JButton)me.getSource());}
	public void mousePressed(MouseEvent me) {if(me.getSource() instanceof JButton) mouseColor((JButton)me.getSource(),true);}
	public void mouseReleased(MouseEvent me) {mouseEntered(me);}
}
