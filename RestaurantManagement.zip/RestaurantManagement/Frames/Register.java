package Frames;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class Register extends JFrame implements MouseListener,ActionListener {
	private JPanel panel;
	private JLabel titlelbl,namlbl,passlbl,repeatlbl,imglbl;
	private JTextField namfld;
	private JPasswordField passfld,repeatfld;
	private JButton rgstrbtn,bckbtn,exitbtn;
	private Color navy,gold,cream;
	private Font myfont;
	private ImageIcon img;

	public Register() {
		super("Restaurant Management System");
		this.setSize(900,550);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		navy=new Color(16,45,82);
		gold=new Color(220,166,49);
		cream=new Color(255,253,247);
		myfont=new Font("Cambria",Font.PLAIN,18);

		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(250,246,235));

		titlelbl=new JLabel("Register Account");
		titlelbl.setBounds(275,55,350,45);
		titlelbl.setFont(new Font("Cambria",Font.BOLD,28));
		titlelbl.setForeground(navy);
		titlelbl.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(titlelbl);

		namlbl=new JLabel("Username");
		namlbl.setBounds(270,135,130,30);
		namlbl.setFont(myfont);
		namlbl.setForeground(navy);
		panel.add(namlbl);

		namfld=new JTextField();
		namfld.setBounds(410,135,230,35);
		namfld.setFont(myfont);
		namfld.setBackground(cream);
		namfld.setBorder(BorderFactory.createLineBorder(gold));
		panel.add(namfld);

		passlbl=new JLabel("Password");
		passlbl.setBounds(270,200,130,30);
		passlbl.setFont(myfont);
		passlbl.setForeground(navy);
		panel.add(passlbl);

		passfld=new JPasswordField();
		passfld.setBounds(410,200,230,35);
		passfld.setFont(myfont);
		passfld.setBackground(cream);
		passfld.setBorder(BorderFactory.createLineBorder(gold));
		passfld.setEchoChar('\u2022');
		panel.add(passfld);

		repeatlbl=new JLabel("Repeat Pass");
		repeatlbl.setBounds(270,265,130,30);
		repeatlbl.setFont(myfont);
		repeatlbl.setForeground(navy);
		panel.add(repeatlbl);

		repeatfld=new JPasswordField();
		repeatfld.setBounds(410,265,230,35);
		repeatfld.setFont(myfont);
		repeatfld.setBackground(cream);
		repeatfld.setBorder(BorderFactory.createLineBorder(gold));
		repeatfld.setEchoChar('\u2022');
		panel.add(repeatfld);

		rgstrbtn=new JButton("Sign Up");
		rgstrbtn.setBounds(270,350,370,42);
		panel.add(rgstrbtn);

		bckbtn=new JButton("Back");
		bckbtn.setBounds(270,415,175,40);
		panel.add(bckbtn);

		exitbtn=new JButton("Exit");
		exitbtn.setBounds(465,415,175,40);
		panel.add(exitbtn);

		JButton button[]={rgstrbtn,bckbtn,exitbtn};
		for(int i=0;i<button.length;i++) {
			button[i].setBackground(cream);
			button[i].setForeground(navy);
			button[i].setBorder(BorderFactory.createLineBorder(navy));
			button[i].setFocusPainted(false);
			button[i].addMouseListener(this);
			button[i].addActionListener(this);
		}
		rgstrbtn.setBackground(gold);
		rgstrbtn.setForeground(Color.WHITE);
		rgstrbtn.setBorder(BorderFactory.createLineBorder(gold));

		img=new ImageIcon("./Images/pr2.jpeg");
		Image image=img.getImage().getScaledInstance(900,550,Image.SCALE_SMOOTH);
		imglbl=new JLabel(new ImageIcon(image));
		imglbl.setBounds(0,0,900,550);
		panel.add(imglbl);
		this.add(panel);
	}

	public void mouseClicked(MouseEvent me){}

	public void mousePressed(MouseEvent me) {
		JButton button=(JButton)me.getSource();
		button.setBackground(navy);
		button.setForeground(Color.WHITE);
	}

	public void mouseReleased(MouseEvent me) {
		mouseEntered(me);
	}

	public void mouseEntered(MouseEvent me) {
		JButton button=(JButton)me.getSource();
		button.setBackground(new Color(235,178,55));
		button.setForeground(navy);
	}

	public void mouseExited(MouseEvent me) {
		JButton button=(JButton)me.getSource();
		button.setBackground(cream);
		button.setForeground(navy);
		if(button==rgstrbtn) {
			button.setBackground(gold);
			button.setForeground(Color.WHITE);
		}
	}

	public void actionPerformed(ActionEvent ae) {
		String s1=namfld.getText();
		String s2=passfld.getText();
		String s3=repeatfld.getText();

		if(ae.getSource()==rgstrbtn) {
			if(s1.isEmpty()||s2.isEmpty()||s3.isEmpty()) {
				JOptionPane.showMessageDialog(this,"Fill up All");
			}
			else if(s2.equals(s3)==false) {
				JOptionPane.showMessageDialog(this,"Password Does Not Match");
			}
			else {
				Account a1=new Account(s1,s2);
				a1.addAccount();
				JOptionPane.showMessageDialog(this,"Registration Successful");
				this.setVisible(false);
				Login f1=new Login();
				f1.setVisible(true);
			}
		}
		else if(ae.getSource()==bckbtn) {
			this.setVisible(false);
			Login f1=new Login();
			f1.setVisible(true);
		}
		else if(ae.getSource()==exitbtn) {
			System.exit(0);
		}
	}
}
