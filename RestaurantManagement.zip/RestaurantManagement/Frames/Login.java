package Frames;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class Login extends JFrame implements MouseListener,ActionListener {
	private JPanel panel;
	private JLabel titlelbl,namlbl,passlbl,imglbl;
	private JTextField namfld;
	private JPasswordField passfld;
	private JButton logbtn,signbtn,exitbtn;
	private Color navy,gold,cream;
	private Font myfont;
	private ImageIcon img;

	public Login() {
		super("Restaurant Management System");
		this.setSize(900,550);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		navy=new Color(16,45,82);
		gold=new Color(220,166,49);
		cream=new Color(255,253,247);
		myfont=new Font("Cambria",Font.PLAIN,18);

		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(250,246,235));

		titlelbl=new JLabel("Restaurant Management System");
		titlelbl.setBounds(220,75,460,50);
		titlelbl.setFont(new Font("Cambria",Font.BOLD,30));
		titlelbl.setForeground(navy);
		titlelbl.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(titlelbl);

		namlbl=new JLabel("Username");
		namlbl.setBounds(280,165,120,30);
		namlbl.setFont(myfont);
		namlbl.setForeground(navy);
		panel.add(namlbl);

		namfld=new JTextField();
		namfld.setBounds(400,165,230,35);
		namfld.setFont(myfont);
		namfld.setBackground(cream);
		namfld.setBorder(BorderFactory.createLineBorder(gold));
		panel.add(namfld);

		passlbl=new JLabel("Password");
		passlbl.setBounds(280,225,120,30);
		passlbl.setFont(myfont);
		passlbl.setForeground(navy);
		panel.add(passlbl);

		passfld=new JPasswordField();
		passfld.setBounds(400,225,230,35);
		passfld.setFont(myfont);
		passfld.setBackground(cream);
		passfld.setBorder(BorderFactory.createLineBorder(gold));
		passfld.setEchoChar('\u2022');
		panel.add(passfld);

		logbtn=new JButton("Login");
		logbtn.setBounds(280,315,350,42);
		panel.add(logbtn);

		signbtn=new JButton("Register");
		signbtn.setBounds(280,380,165,40);
		panel.add(signbtn);

		exitbtn=new JButton("Exit");
		exitbtn.setBounds(465,380,165,40);
		panel.add(exitbtn);

		JButton button[]={logbtn,signbtn,exitbtn};
		for(int i=0;i<button.length;i++) {
			button[i].setBackground(cream);
			button[i].setForeground(navy);
			button[i].setBorder(BorderFactory.createLineBorder(navy));
			button[i].setFocusPainted(false);
			button[i].addMouseListener(this);
			button[i].addActionListener(this);
		}
		logbtn.setBackground(gold);
		logbtn.setForeground(Color.WHITE);
		logbtn.setBorder(BorderFactory.createLineBorder(gold));

		img=new ImageIcon("./Images/pr2.jpeg");
		Image image=img.getImage().getScaledInstance(900,550,Image.SCALE_SMOOTH);
		imglbl=new JLabel(new ImageIcon(image));
		imglbl.setBounds(0,0,900,550);
		panel.add(imglbl);
		this.add(panel);
	}

	public void mouseClicked(MouseEvent me){}

	public void mousePressed(MouseEvent me) {
		JButton button=(JButton)me.getSource();
		button.setBackground(navy);
		button.setForeground(Color.WHITE);
	}

	public void mouseReleased(MouseEvent me) {
		mouseEntered(me);
	}

	public void mouseEntered(MouseEvent me) {
		JButton button=(JButton)me.getSource();
		button.setBackground(new Color(235,178,55));
		button.setForeground(navy);
	}

	public void mouseExited(MouseEvent me) {
		JButton button=(JButton)me.getSource();
		button.setBackground(cream);
		button.setForeground(navy);
		if(button==logbtn) {
			button.setBackground(gold);
			button.setForeground(Color.WHITE);
		}
	}

	public void actionPerformed(ActionEvent ae) {
		String n=namfld.getText();
		String p=passfld.getText();

		if(ae.getSource()==signbtn) {
			this.setVisible(false);
			Register r1=new Register();
			r1.setVisible(true);
		}
		else if(ae.getSource()==exitbtn) {
			System.exit(0);
		}
		else if(ae.getSource()==logbtn) {
			if(n.isEmpty()||p.isEmpty()) {
				JOptionPane.showMessageDialog(this,"Fill up All");
			}
			else {
				Account a1=new Account();
				boolean flag=a1.getAccount(n,p);

				if(flag==true) {
					this.setVisible(false);
					Homepage h1=new Homepage(n,this);
					h1.setVisible(true);
				}
				else {
					JOptionPane.showMessageDialog(this,"Invalid Username or Password");
				}
			}
		}
	}
}
