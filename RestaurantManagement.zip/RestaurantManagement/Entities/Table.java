package Entities;

import java.lang.*;
import java.util.*;
import java.io.*;
import Frames.*;

public class Table
{
	private String tnumber;
	private File myfile;
	private FileWriter fwriter;
	private Scanner sc;

	public Table()
	{

	}

	public Table(String tnumber)
	{
		this.tnumber=tnumber;
	}

	public void setTnumber(String tnumber)
	{
		this.tnumber=tnumber;
	}

	public String getTnumber()
	{
		return tnumber;
	}

	public void addTable()
	{
		try
		{
			myfile=new File("./Datas/Table.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile,true);

			fwriter.write(getTnumber()+"\n");

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public int getTable(String value[])
	{
		int total=0;

		try
		{
			myfile=new File("./Datas/Table.txt");
			myfile.createNewFile();
			sc=new Scanner(myfile);

			while(sc.hasNextLine()&&total<value.length)
			{
				String line=sc.nextLine();

				if(line.isEmpty()==false)
				{
					value[total]=line;
					total++;
				}
			}

			sc.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}

		return total;
	}

	public void saveTable(String value[],int total)
	{
		try
		{
			myfile=new File("./Datas/Table.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile);

			for(int i=0;i<total;i++)
			{
				fwriter.write(value[i]+"\n");
			}

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
}
