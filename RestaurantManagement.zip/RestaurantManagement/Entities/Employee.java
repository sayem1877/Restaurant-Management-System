package Entities;

import java.lang.*;
import java.util.*;
import java.io.*;
import Frames.*;

public class Employee
{
	private String ename;
	private File myfile;
	private FileWriter fwriter;
	private Scanner sc;

	public Employee()
	{

	}

	public Employee(String ename)
	{
		this.ename=ename;
	}

	public void setEname(String ename)
	{
		this.ename=ename;
	}

	public String getEname()
	{
		return ename;
	}

	public void addEmployee()
	{
		try
		{
			myfile=new File("./Datas/Employee.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile,true);

			fwriter.write(getEname()+"\n");

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public int getEmployee(String value[])
	{
		int total=0;

		try
		{
			myfile=new File("./Datas/Employee.txt");
			myfile.createNewFile();
			sc=new Scanner(myfile);

			while(sc.hasNextLine()&&total<value.length)
			{
				String line=sc.nextLine();

				if(line.isEmpty()==false)
				{
					value[total]=line;
					total++;
				}
			}

			sc.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}

		return total;
	}

	public void saveEmployee(String value[],int total)
	{
		try
		{
			myfile=new File("./Datas/Employee.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile);

			for(int i=0;i<total;i++)
			{
				fwriter.write(value[i]+"\n");
			}

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
}
