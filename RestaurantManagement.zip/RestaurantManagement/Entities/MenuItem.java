package Entities;

import java.lang.*;
import java.util.*;
import java.io.*;
import Frames.*;

public class MenuItem
{
	private String iname;
	private String iprice;
	private File myfile;
	private FileWriter fwriter;
	private Scanner sc;

	public MenuItem()
	{

	}

	public MenuItem(String iname,String iprice)
	{
		this.iname=iname;
		this.iprice=iprice;
	}

	public void setIname(String iname)
	{
		this.iname=iname;
	}

	public void setIprice(String iprice)
	{
		this.iprice=iprice;
	}

	public String getIname()
	{
		return iname;
	}

	public String getIprice()
	{
		return iprice;
	}

	public void addMenuItem()
	{
		try
		{
			myfile=new File("./Datas/MenuItem.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile,true);

			fwriter.write(getIname()+"\t");
			fwriter.write(getIprice()+"\n");

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public int getMenuItem(String value[])
	{
		int total=0;

		try
		{
			myfile=new File("./Datas/MenuItem.txt");
			myfile.createNewFile();
			sc=new Scanner(myfile);

			while(sc.hasNextLine()&&total<value.length)
			{
				String line=sc.nextLine();
				String data[]=line.split("\t");

				if(data.length==2)
				{
					value[total]=line;
					total++;
				}
			}

			sc.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}

		return total;
	}

	public void saveMenuItem(String value[],int total)
	{
		try
		{
			myfile=new File("./Datas/MenuItem.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile);

			for(int i=0;i<total;i++)
			{
				fwriter.write(value[i]+"\n");
			}

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
}
