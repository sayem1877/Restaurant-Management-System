package Entities;

import java.lang.*;
import java.util.*;
import java.io.*;
import Frames.*;

public class Order
{
	private String oid;
	private String cname;
	private String phone;
	private String tnumber;
	private String otime;
	private String ename;
	private OrderItem oitem;
	private File myfile;
	private FileWriter fwriter;
	private Scanner sc;

	public Order()
	{

	}

	public Order(String oid,String cname,String phone,String tnumber,String otime,String ename,OrderItem oitem)
	{
		this.oid=oid;
		this.cname=cname;
		this.phone=phone;
		this.tnumber=tnumber;
		this.otime=otime;
		this.ename=ename;
		this.oitem=oitem;
	}

	public void setOid(String oid)
	{
		this.oid=oid;
	}

	public void setCname(String cname)
	{
		this.cname=cname;
	}

	public void setPhone(String phone)
	{
		this.phone=phone;
	}

	public void setTnumber(String tnumber)
	{
		this.tnumber=tnumber;
	}

	public void setOtime(String otime)
	{
		this.otime=otime;
	}

	public void setEname(String ename)
	{
		this.ename=ename;
	}

	public void setOitem(OrderItem oitem)
	{
		this.oitem=oitem;
	}

	public String getOid()
	{
		return oid;
	}

	public String getCname()
	{
		return cname;
	}

	public String getPhone()
	{
		return phone;
	}

	public String getTnumber()
	{
		return tnumber;
	}

	public String getOtime()
	{
		return otime;
	}

	public String getEname()
	{
		return ename;
	}

	public OrderItem getOitem()
	{
		return oitem;
	}

	public void addOrder()
	{
		try
		{
			myfile=new File("./Datas/Orders.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile,true);

			fwriter.write(getOid()+"\t");
			fwriter.write(getCname()+"\t");
			fwriter.write(getPhone()+"\t");
			fwriter.write(getTnumber()+"\t");
			fwriter.write(getOtime()+"\t");
			fwriter.write(getEname()+"\t");
			fwriter.write(getOitem().getIname()+"\t");
			fwriter.write(getOitem().getIquantity()+"\t");
			fwriter.write(getOitem().getIprice()+"\t");
			fwriter.write(getOitem().getItotal()+"\n");

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public int getOrder(Order value[])
	{
		int total=0;

		try
		{
			myfile=new File("./Datas/Orders.txt");
			myfile.createNewFile();
			sc=new Scanner(myfile);

			while(sc.hasNextLine()&&total<value.length)
			{
				String line=sc.nextLine();
				String data[]=line.split("\t");

				if(data.length==10)
				{
					OrderItem o1=new OrderItem(data[6],data[7],data[8],data[9]);
					value[total]=new Order(data[0],data[1],data[2],data[3],data[4],data[5],o1);
					total++;
				}
			}

			sc.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}

		return total;
	}

	public void saveOrder(Order value[],int total)
	{
		try
		{
			myfile=new File("./Datas/Orders.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile);

			for(int i=0;i<total;i++)
			{
				fwriter.write(value[i].getOid()+"\t");
				fwriter.write(value[i].getCname()+"\t");
				fwriter.write(value[i].getPhone()+"\t");
				fwriter.write(value[i].getTnumber()+"\t");
				fwriter.write(value[i].getOtime()+"\t");
				fwriter.write(value[i].getEname()+"\t");
				fwriter.write(value[i].getOitem().getIname()+"\t");
				fwriter.write(value[i].getOitem().getIquantity()+"\t");
				fwriter.write(value[i].getOitem().getIprice()+"\t");
				fwriter.write(value[i].getOitem().getItotal()+"\n");
			}

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
}
