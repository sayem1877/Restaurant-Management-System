package Entities;

import java.lang.*;
import java.util.*;
import java.io.*;
import Frames.*;

public class OrderItem
{
	private String iname;
	private String iquantity;
	private String iprice;
	private String itotal;
	private File myfile;
	private FileWriter fwriter;
	private Scanner sc;

	public OrderItem()
	{

	}

	public OrderItem(String iname,String iquantity,String iprice,String itotal)
	{
		this.iname=iname;
		this.iquantity=iquantity;
		this.iprice=iprice;
		this.itotal=itotal;
	}

	public void setIname(String iname)
	{
		this.iname=iname;
	}

	public void setIquantity(String iquantity)
	{
		this.iquantity=iquantity;
	}

	public void setIprice(String iprice)
	{
		this.iprice=iprice;
	}

	public void setItotal(String itotal)
	{
		this.itotal=itotal;
	}

	public String getIname()
	{
		return iname;
	}

	public String getIquantity()
	{
		return iquantity;
	}

	public String getIprice()
	{
		return iprice;
	}

	public String getItotal()
	{
		return itotal;
	}

	public void addOrderItem()
	{
		try
		{
			myfile=new File("./Datas/OrderItem.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile,true);

			fwriter.write(getIname()+"\t");
			fwriter.write(getIquantity()+"\t");
			fwriter.write(getIprice()+"\n");

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public int getOrderItem(String value[])
	{
		int total=0;

		try
		{
			myfile=new File("./Datas/OrderItem.txt");
			myfile.createNewFile();
			sc=new Scanner(myfile);

			while(sc.hasNextLine()&&total<value.length)
			{
				String line=sc.nextLine();
				String data[]=line.split("\t");

				if(data.length==3)
				{
					value[total]=line;
					total++;
				}
			}

			sc.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}

		return total;
	}

	public void saveOrderItem(String value[],int total)
	{
		try
		{
			myfile=new File("./Datas/OrderItem.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile);

			for(int i=0;i<total;i++)
			{
				fwriter.write(value[i]+"\n");
			}

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
}
