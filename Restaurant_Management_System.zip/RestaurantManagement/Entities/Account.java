package Entities;

import java.lang.*;
import java.util.*;
import java.io.*;
import Frames.*;

public class Account
{
	private String uname;
	private String upass;
	private File myfile;
	private FileWriter fwriter;
	private Scanner sc;

	public Account()
	{

	}

	public Account(String uname,String upass)
	{
		this.uname=uname;
		this.upass=upass;
	}

	public void setUname(String uname)
	{
		this.uname=uname;
	}

	public void setUpass(String upass)
	{
		this.upass=upass;
	}

	public String getUname()
	{
		return uname;
	}

	public String getUpass()
	{
		return upass;
	}

	public void addAccount()
	{
		try
		{
			myfile=new File("./Datas/Data.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile,true);

			fwriter.write(getUname()+"\t");
			fwriter.write(getUpass()+"\n");

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public void addAdmin()
	{
		try
		{
			myfile=new File("./Datas/Admin.txt");
			myfile.createNewFile();
			fwriter=new FileWriter(myfile,true);

			fwriter.write(getUname()+"\t");
			fwriter.write(getUpass()+"\n");

			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public boolean getAccount(String s1,String s2)
	{
		boolean flag=false;

		try
		{
			myfile=new File("./Datas/Data.txt");
			myfile.createNewFile();
			sc=new Scanner(myfile);

			while(sc.hasNextLine())
			{
				String line=sc.nextLine();
				String value[]=line.split("\t");

				if(value.length==2&&value[0].equals(s1)&&value[1].equals(s2))
				{
					flag=true;
				}
			}

			sc.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}

		return flag;
	}

	public boolean getAdmin(String s1,String s2)
	{
		boolean flag=false;

		try
		{
			myfile=new File("./Datas/Admin.txt");
			myfile.createNewFile();
			sc=new Scanner(myfile);

			while(sc.hasNextLine())
			{
				String line=sc.nextLine();
				String value[]=line.split("\t");

				if(value.length==2&&value[0].equals(s1)&&value[1].equals(s2))
				{
					flag=true;
				}
			}

			sc.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}

		return flag;
	}
}
