package Frames;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;
public class Login extends JFrame implements MouseListener,ActionListener
{
	private JPanel panel;
	private JLabel titlelbl,namlbl,passlbl,rolelbl,imglbl;
	private JTextField namfld;
	private JPasswordField passfld;
	private JComboBox rolebox;
	private JButton logbtn,signbtn,exitbtn;
	private Color navy,gold,fieldcolor;
	private Font myfont;
	private ImageIcon img;
	public Login()
	{
		super("Restaurant Management System");
		this.setSize(900,550);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		navy=new Color(16,45,82);
		gold=new Color(220,166,49);
		fieldcolor=new Color(255,253,247);
		myfont=new Font("Cambria",Font.PLAIN,18);
		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(250,246,235));
		titlelbl=new JLabel("Welcome Back");
		titlelbl.setBounds(280,70,340,50);
		titlelbl.setFont(new Font("Cambria",Font.BOLD,30));
		titlelbl.setForeground(navy);
		titlelbl.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(titlelbl);
		namlbl=new JLabel("Username");
		namlbl.setBounds(280,145,120,30);
		namlbl.setFont(myfont);
		namlbl.setForeground(navy);
		panel.add(namlbl);
		namfld=new JTextField();
		namfld.setBounds(400,145,230,35);
		namfld.setFont(myfont);
		namfld.setBackground(fieldcolor);
		namfld.setBorder(BorderFactory.createLineBorder(gold));
		panel.add(namfld);
		passlbl=new JLabel("Password");
		passlbl.setBounds(280,205,120,30);
		passlbl.setFont(myfont);
		passlbl.setForeground(navy);
		panel.add(passlbl);
		passfld=new JPasswordField();
		passfld.setBounds(400,205,230,35);
		passfld.setFont(myfont);
		passfld.setBackground(fieldcolor);
		passfld.setBorder(BorderFactory.createLineBorder(gold));
		passfld.setEchoChar('\u2022');
		panel.add(passfld);
		rolelbl=new JLabel("Login As");
		rolelbl.setBounds(280,265,120,30);
		rolelbl.setFont(myfont);
		rolelbl.setForeground(navy);
		panel.add(rolelbl);
		String role[]={"Customer","Admin"};
		rolebox=new JComboBox(role);
		rolebox.setBounds(400,265,230,35);
		rolebox.setFont(myfont);
		rolebox.setBackground(fieldcolor);
		rolebox.setBorder(BorderFactory.createLineBorder(gold));
		panel.add(rolebox);
		logbtn=new JButton("Login");
		logbtn.setBounds(280,335,350,42);
		panel.add(logbtn);
		signbtn=new JButton("Register");
		signbtn.setBounds(280,395,165,40);
		panel.add(signbtn);
		exitbtn=new JButton("Exit");
		exitbtn.setBounds(465,395,165,40);
		panel.add(exitbtn);
		JButton button[]={logbtn,signbtn,exitbtn};
		for(int i=0;i<button.length;i++)
		{
			button[i].setBackground(navy);
			button[i].setForeground(Color.WHITE);
			button[i].setBorder(BorderFactory.createLineBorder(gold));
			button[i].setFocusPainted(false);
			button[i].addMouseListener(this);
			button[i].addActionListener(this);
		}
		logbtn.setBackground(gold);
		signbtn.setBackground(fieldcolor);
		signbtn.setForeground(navy);
		signbtn.setBorder(BorderFactory.createLineBorder(navy));
		exitbtn.setBackground(fieldcolor);
		exitbtn.setForeground(navy);
		exitbtn.setBorder(BorderFactory.createLineBorder(gold));
		img=new ImageIcon("./Images/pr2.jpeg");
		Image image=img.getImage().getScaledInstance(900,550,Image.SCALE_SMOOTH);
		imglbl=new JLabel(new ImageIcon(image));
		imglbl.setBounds(0,0,900,550);
		panel.add(imglbl);
		this.add(panel);
	}
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me)
	{
		JButton button=(JButton)me.getSource();
		button.setBackground(navy);
		button.setForeground(Color.WHITE);
	}
	public void mouseReleased(MouseEvent me)
	{
		mouseEntered(me);
	}
	public void mouseEntered(MouseEvent me)
	{
		JButton button=(JButton)me.getSource();
		button.setBackground(new Color(235,178,55));
		button.setForeground(navy);
	}
	public void mouseExited(MouseEvent me)
	{
		JButton button=(JButton)me.getSource();
		if(button==logbtn)
		{
			button.setBackground(gold);
			button.setForeground(Color.WHITE);
		}
		else
		{
			button.setBackground(fieldcolor);
			button.setForeground(navy);
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		String n=namfld.getText();
		String p=passfld.getText();
		String r=rolebox.getSelectedItem().toString();
		if(ae.getSource()==signbtn)
		{
			this.setVisible(false);
			Register r1=new Register();
			r1.setVisible(true);
		}
		else if(ae.getSource()==exitbtn)
		{
			System.exit(0);
		}
		else if(ae.getSource()==logbtn)
		{
			if(n.isEmpty()||p.isEmpty())
			{
				JOptionPane.showMessageDialog(this,"Fill up All");
			}
			else
			{
				Account a1=new Account();
				boolean flag=false;
				if(r.equals("Admin"))
				{
					flag=a1.getAdmin(n,p);
				}
				else
				{
					flag=a1.getAccount(n,p);
				}
				if(flag==true)
				{
					this.setVisible(false);
					if(r.equals("Admin"))
					{
						Admin a2=new Admin(n,this);
						a2.setVisible(true);
					}
					else
					{
						Homepage h1=new Homepage(n,this);
						h1.setVisible(true);
					}
				}
				else
				{
					JOptionPane.showMessageDialog(this,"Invalid Username or Password");
				}
			}
		}
	}
}
