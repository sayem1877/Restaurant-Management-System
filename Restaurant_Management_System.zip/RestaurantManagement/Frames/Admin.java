package Frames;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;
import Entities.MenuItem;
public class Admin extends JFrame implements MouseListener,ActionListener
{
	private JPanel panel,sidepanel;
	private JLabel titlelbl,userlbl,recordlbl,hintlbl,imglbl;
	private JTextField recordfld;
	private JTextArea listarea;
	private JScrollPane scroll;
	private JButton employeebtn,menubtn,tablebtn,orderbtn,orderitembtn,bckbtn;
	private JButton addbtn,updatebtn,deletebtn;
	private Login f1;
	private String vr;
	private String type[]={"Employee","Menu Item","Table","Order Item"};
	private String data[][]=new String[4][100];
	private int total[]={0,0,0,0};
	private int current=0;
	private int selected=-1;
	private Color navy,gold,cream;
	private Font myfont;
	private ImageIcon img;
	public Admin(String vr,Login f1)
	{
		super("Restaurant Admin Panel");
		this.setSize(1000,600);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.vr=vr;
		this.f1=f1;
		navy=new Color(16,45,82);
		gold=new Color(220,166,49);
		cream=new Color(255,253,247);
		myfont=new Font("Cambria",Font.PLAIN,17);
		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(250,246,235));
		sidepanel=new JPanel();
		sidepanel.setLayout(null);
		sidepanel.setBounds(0,0,220,600);
		sidepanel.setBackground(navy);
		panel.add(sidepanel);
		titlelbl=new JLabel("Admin Panel");
		titlelbl.setBounds(245,20,500,45);
		titlelbl.setFont(new Font("Cambria",Font.BOLD,30));
		titlelbl.setForeground(navy);
		panel.add(titlelbl);
		userlbl=new JLabel("User: "+vr);
		userlbl.setBounds(760,25,190,35);
		userlbl.setFont(myfont);
		userlbl.setForeground(navy);
		userlbl.setHorizontalAlignment(SwingConstants.RIGHT);
		panel.add(userlbl);
		employeebtn=makeButton("Employees",25,80,170,40);
		menubtn=makeButton("Menu Items",25,135,170,40);
		tablebtn=makeButton("Tables",25,190,170,40);
		orderbtn=makeButton("Orders",25,245,170,40);
		orderitembtn=makeButton("Order Items",25,300,170,40);
		bckbtn=makeButton("Back to Login",25,490,170,40);
		sidepanel.add(employeebtn);
		sidepanel.add(menubtn);
		sidepanel.add(tablebtn);
		sidepanel.add(orderbtn);
		sidepanel.add(orderitembtn);
		sidepanel.add(bckbtn);
		recordlbl=new JLabel();
		recordlbl.setBounds(250,85,700,28);
		recordlbl.setFont(myfont);
		recordlbl.setForeground(navy);
		panel.add(recordlbl);
		hintlbl=new JLabel();
		hintlbl.setBounds(250,115,700,24);
		hintlbl.setFont(new Font("Cambria",Font.ITALIC,14));
		hintlbl.setForeground(new Color(85,90,100));
		panel.add(hintlbl);
		recordfld=new JTextField();
		recordfld.setBounds(250,150,700,38);
		recordfld.setFont(myfont);
		recordfld.setBackground(cream);
		recordfld.setBorder(BorderFactory.createLineBorder(gold));
		panel.add(recordfld);
		addbtn=makeButton("Add",250,210,130,40);
		updatebtn=makeButton("Update",400,210,130,40);
		deletebtn=makeButton("Delete",550,210,130,40);
		panel.add(addbtn);
		panel.add(updatebtn);
		panel.add(deletebtn);
		listarea=new JTextArea();
		listarea.setFont(new Font("Monospaced",Font.PLAIN,15));
		listarea.setForeground(navy);
		listarea.setBackground(cream);
		listarea.setEditable(false);
		listarea.addMouseListener(this);
		scroll=new JScrollPane(listarea);
		scroll.setBounds(250,275,700,255);
		scroll.setBorder(BorderFactory.createLineBorder(gold));
		panel.add(scroll);
		loadData();
		showData();
		img=new ImageIcon("./Images/pr2.jpeg");
		Image image=img.getImage().getScaledInstance(1000,600,Image.SCALE_SMOOTH);
		imglbl=new JLabel(new ImageIcon(image));
		imglbl.setBounds(0,0,1000,600);
		panel.add(imglbl);
		this.add(panel);
	}
	private JButton makeButton(String text,int x,int y,int width,int height)
	{
		JButton button=new JButton(text);
		button.setBounds(x,y,width,height);
		button.setFocusPainted(false);
		button.addMouseListener(this);
		button.addActionListener(this);
		normalButton(button);
		return button;
	}
	private void normalButton(JButton button)
	{
		String text=button.getText();
		button.setBackground(navy);
		button.setForeground(Color.WHITE);
		button.setBorder(BorderFactory.createLineBorder(navy));
		if(text.equals("Add")||current==0&&text.equals("Employees")||current==1&&text.equals("Menu Items")||current==2&&text.equals("Tables")||current==3&&text.equals("Order Items"))
		{
			button.setBackground(gold);
			button.setBorder(BorderFactory.createLineBorder(gold));
		}
		else if(text.equals("Back to Login"))
		{
			button.setBackground(cream);
			button.setForeground(navy);
		}
	}
	private void loadData()
	{
		Employee e1=new Employee();
		total[0]=e1.getEmployee(data[0]);
		MenuItem m1=new MenuItem();
		total[1]=m1.getMenuItem(data[1]);
		Table t1=new Table();
		total[2]=t1.getTable(data[2]);
		OrderItem o1=new OrderItem();
		total[3]=o1.getOrderItem(data[3]);
	}
	private void showData()
	{
		selected=-1;
		recordfld.setText("");
		if(current==0)
		{
			recordlbl.setText("Employee Name");
			hintlbl.setText("Enter one employee name.");
		}
		else if(current==1)
		{
			recordlbl.setText("Menu Item");
			hintlbl.setText("Enter: Item Name, Price");
		}
		else if(current==2)
		{
			recordlbl.setText("Table Number");
			hintlbl.setText("Enter one table number.");
		}
		else
		{
			recordlbl.setText("Order Item");
			hintlbl.setText("Enter: Item Name, Quantity, Unit Price");
		}
		String text=type[current]+" Records\n\n";
		if(total[current]==0)
			text=text+"No records yet.\n";
		for(int i=0;i<total[current];i++)
			text=text+(i+1)+". "+data[current][i].replace("\t"," | ")+"\n";
		listarea.setText(text);
		JButton button[]={employeebtn,menubtn,tablebtn,orderitembtn};
		for(int i=0;i<button.length;i++)
			normalButton(button[i]);
	}
	private String getRecord()
	{
		String record=recordfld.getText().trim();
		if(current==0||current==2)
		{
			return record;
		}
		String value[]=record.split(",");
		if(current==1&&value.length==2)
		{
			return value[0].trim()+"\t"+value[1].trim();
		}
		else if(current==3&&value.length==3)
		{
			return value[0].trim()+"\t"+value[1].trim()+"\t"+value[2].trim();
		}
		return "";
	}
	private boolean getExists(String record)
	{
		boolean flag=false;
		for(int i=0;i<total[current];i++)
		{
			if(data[current][i].equals(record))
				flag=true;
		}
		return flag;
	}
	private void addRecord()
	{
		String record=getRecord();
		if(record.isEmpty())
		{
			JOptionPane.showMessageDialog(this,"Enter the record in the shown format");
			return;
		}
		if(getExists(record)==true)
		{
			JOptionPane.showMessageDialog(this,"This record already exists");
			return;
		}
		if(total[current]>=100)
		{
			JOptionPane.showMessageDialog(this,"Record limit reached");
			return;
		}
		data[current][total[current]]=record;
		total[current]++;
		if(current==0)
		{
			Employee e1=new Employee(record);
			e1.addEmployee();
		}
		else if(current==1)
		{
			String value[]=record.split("\t");
			MenuItem m1=new MenuItem(value[0],value[1]);
			m1.addMenuItem();
		}
		else if(current==2)
		{
			Table t1=new Table(record);
			t1.addTable();
		}
		else
		{
			String value[]=record.split("\t");
			OrderItem o1=new OrderItem(value[0],value[1],value[2],"");
			o1.addOrderItem();
		}
		showData();
	}
	private void updateRecord()
	{
		String record=getRecord();
		if(selected<0||record.isEmpty())
		{
			JOptionPane.showMessageDialog(this,"Select a record and enter the new value");
			return;
		}
		data[current][selected]=record;
		saveData();
		showData();
	}
	private void deleteRecord()
	{
		if(selected<0)
		{
			JOptionPane.showMessageDialog(this,"Select a record first");
			return;
		}
		for(int i=selected;i<total[current]-1;i++)
		{
			data[current][i]=data[current][i+1];
		}
		total[current]--;
		data[current][total[current]]=null;
		saveData();
		showData();
	}
	private void saveData()
	{
		if(current==0)
		{
			Employee e1=new Employee();
			e1.saveEmployee(data[0],total[0]);
		}
		else if(current==1)
		{
			MenuItem m1=new MenuItem();
			m1.saveMenuItem(data[1],total[1]);
		}
		else if(current==2)
		{
			Table t1=new Table();
			t1.saveTable(data[2],total[2]);
		}
		else
		{
			OrderItem o1=new OrderItem();
			o1.saveOrderItem(data[3],total[3]);
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==employeebtn)
		{
			current=0;
			showData();
		}
		else if(ae.getSource()==menubtn)
		{
			current=1;
			showData();
		}
		else if(ae.getSource()==tablebtn)
		{
			current=2;
			showData();
		}
		else if(ae.getSource()==orderitembtn)
		{
			current=3;
			showData();
		}
		else if(ae.getSource()==orderbtn)
		{
			this.setVisible(false);
			Customer c1=new Customer(vr,f1,true);
			c1.setVisible(true);
		}
		else if(ae.getSource()==bckbtn)
		{
			this.setVisible(false);
			f1.setVisible(true);
		}
		else if(ae.getSource()==addbtn)
			addRecord();
		else if(ae.getSource()==updatebtn)
			updateRecord();
		else if(ae.getSource()==deletebtn)
			deleteRecord();
	}
	public void mouseClicked(MouseEvent me)
	{
		if(me.getSource()!=listarea)
			return;
		try
		{
			int line=listarea.getLineOfOffset(listarea.getCaretPosition());
			line=line-2;
			if(line>=0&&line<total[current])
			{
				selected=line;
				recordfld.setText(data[current][selected].replace("\t",","));
			}
		}
		catch(Exception e)
		{
		}
	}
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource() instanceof JButton)
		{
			JButton button=(JButton)me.getSource();
			button.setBackground(new Color(235,178,55));
			button.setForeground(navy);
		}
	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource() instanceof JButton)
			normalButton((JButton)me.getSource());
	}
	public void mousePressed(MouseEvent me)
	{
		if(me.getSource() instanceof JButton)
		{
			JButton button=(JButton)me.getSource();
			button.setBackground(navy);
			button.setForeground(Color.WHITE);
		}
	}
	public void mouseReleased(MouseEvent me)
	{
		mouseEntered(me);
	}
}
