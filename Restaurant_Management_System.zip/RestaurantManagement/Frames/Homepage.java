package Frames;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;
public class Homepage extends JFrame implements MouseListener,ActionListener
{
	private JPanel panel;
	private JLabel titlelbl,welcomelbl,imglbl;
	private JButton orderbtn,searchbtn,bckbtn;
	private Login f1;
	private String vr;
	private Color navy,gold;
	private ImageIcon img;
	public Homepage(String vr,Login f1)
	{
		super("Restaurant Dashboard");
		this.setSize(900,550);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.vr=vr;
		this.f1=f1;
		navy=new Color(16,45,82);
		gold=new Color(220,166,49);
		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(250,246,235));
		titlelbl=new JLabel("Dashboard");
		titlelbl.setBounds(280,75,340,50);
		titlelbl.setFont(new Font("Cambria",Font.BOLD,32));
		titlelbl.setForeground(navy);
		titlelbl.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(titlelbl);
		welcomelbl=new JLabel("Welcome, "+vr);
		welcomelbl.setBounds(300,130,300,35);
		welcomelbl.setFont(new Font("Cambria",Font.PLAIN,20));
		welcomelbl.setForeground(navy);
		welcomelbl.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(welcomelbl);
		orderbtn=new JButton("Customer Order Panel");
		orderbtn.setBounds(260,205,380,50);
		panel.add(orderbtn);
		searchbtn=new JButton("Search Orders");
		searchbtn.setBounds(260,280,380,50);
		panel.add(searchbtn);
		bckbtn=new JButton("Logout");
		bckbtn.setBounds(260,355,380,50);
		panel.add(bckbtn);
		JButton button[]={orderbtn,searchbtn,bckbtn};
		for(int i=0;i<button.length;i++)
		{
			button[i].setBackground(navy);
			button[i].setForeground(Color.WHITE);
			button[i].setBorder(BorderFactory.createLineBorder(gold));
			button[i].setFocusPainted(false);
			button[i].addMouseListener(this);
			button[i].addActionListener(this);
		}
		orderbtn.setBackground(gold);
		bckbtn.setBackground(new Color(255,253,247));
		bckbtn.setForeground(navy);
		bckbtn.setBorder(BorderFactory.createLineBorder(navy));
		img=new ImageIcon("./Images/pr2.jpeg");
		Image image=img.getImage().getScaledInstance(900,550,Image.SCALE_SMOOTH);
		imglbl=new JLabel(new ImageIcon(image));
		imglbl.setBounds(0,0,900,550);
		panel.add(imglbl);
		this.add(panel);
	}
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me)
	{
		JButton button=(JButton)me.getSource();
		button.setBackground(navy);
		button.setForeground(Color.WHITE);
	}
	public void mouseReleased(MouseEvent me)
	{
		mouseEntered(me);
	}
	public void mouseEntered(MouseEvent me)
	{
		JButton button=(JButton)me.getSource();
		button.setBackground(new Color(235,178,55));
		button.setForeground(navy);
	}
	public void mouseExited(MouseEvent me)
	{
		JButton button=(JButton)me.getSource();
		if(button==orderbtn)
		{
			button.setBackground(gold);
			button.setForeground(Color.WHITE);
		}
		else if(button==bckbtn)
		{
			button.setBackground(new Color(255,253,247));
			button.setForeground(navy);
		}
		else
		{
			button.setBackground(navy);
			button.setForeground(Color.WHITE);
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==orderbtn||ae.getSource()==searchbtn)
		{
			this.setVisible(false);
			Customer c1=new Customer(vr,f1);
			c1.setVisible(true);
		}
		else if(ae.getSource()==bckbtn)
		{
			this.setVisible(false);
			f1.setVisible(true);
		}
	}
}
