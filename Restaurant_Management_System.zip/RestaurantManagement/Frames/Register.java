package Frames;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;
public class Register extends JFrame implements MouseListener,ActionListener
{
	private JPanel panel;
	private JLabel titlelbl,rolelbl,namlbl,passlbl,repeatlbl,imglbl;
	private JTextField namfld;
	private JPasswordField passfld,repeatfld;
	private JComboBox rolebox;
	private JButton rgstrbtn,bckbtn,exitbtn;
	private Color navy,gold,fieldcolor;
	private Font myfont;
	private ImageIcon img;
	public Register()
	{
		super("Restaurant Management System");
		this.setSize(900,550);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		navy=new Color(16,45,82);
		gold=new Color(220,166,49);
		fieldcolor=new Color(255,253,247);
		myfont=new Font("Cambria",Font.PLAIN,18);
		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(250,246,235));
		titlelbl=new JLabel("Register Account");
		titlelbl.setBounds(275,45,350,45);
		titlelbl.setFont(new Font("Cambria",Font.BOLD,28));
		titlelbl.setForeground(navy);
		titlelbl.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(titlelbl);
		rolelbl=new JLabel("Register As");
		rolelbl.setBounds(270,115,130,30);
		rolelbl.setFont(myfont);
		rolelbl.setForeground(navy);
		panel.add(rolelbl);
		String role[]={"Customer","Admin"};
		rolebox=new JComboBox(role);
		rolebox.setBounds(410,115,230,35);
		rolebox.setFont(myfont);
		rolebox.setBackground(fieldcolor);
		rolebox.setBorder(BorderFactory.createLineBorder(gold));
		panel.add(rolebox);
		namlbl=new JLabel("Username");
		namlbl.setBounds(270,175,130,30);
		namlbl.setFont(myfont);
		namlbl.setForeground(navy);
		panel.add(namlbl);
		namfld=new JTextField();
		namfld.setBounds(410,175,230,35);
		namfld.setFont(myfont);
		namfld.setBackground(fieldcolor);
		namfld.setBorder(BorderFactory.createLineBorder(gold));
		panel.add(namfld);
		passlbl=new JLabel("Password");
		passlbl.setBounds(270,235,130,30);
		passlbl.setFont(myfont);
		passlbl.setForeground(navy);
		panel.add(passlbl);
		passfld=new JPasswordField();
		passfld.setBounds(410,235,230,35);
		passfld.setFont(myfont);
		passfld.setBackground(fieldcolor);
		passfld.setBorder(BorderFactory.createLineBorder(gold));
		passfld.setEchoChar('\u2022');
		panel.add(passfld);
		repeatlbl=new JLabel("Repeat Pass");
		repeatlbl.setBounds(270,295,130,30);
		repeatlbl.setFont(myfont);
		repeatlbl.setForeground(navy);
		panel.add(repeatlbl);
		repeatfld=new JPasswordField();
		repeatfld.setBounds(410,295,230,35);
		repeatfld.setFont(myfont);
		repeatfld.setBackground(fieldcolor);
		repeatfld.setBorder(BorderFactory.createLineBorder(gold));
		repeatfld.setEchoChar('\u2022');
		panel.add(repeatfld);
		rgstrbtn=new JButton("Sign Up");
		rgstrbtn.setBounds(270,365,370,42);
		panel.add(rgstrbtn);
		bckbtn=new JButton("Back");
		bckbtn.setBounds(270,425,175,40);
		panel.add(bckbtn);
		exitbtn=new JButton("Exit");
		exitbtn.setBounds(465,425,175,40);
		panel.add(exitbtn);
		JButton button[]={rgstrbtn,bckbtn,exitbtn};
		for(int i=0;i<button.length;i++)
		{
			button[i].setBackground(navy);
			button[i].setForeground(Color.WHITE);
			button[i].setBorder(BorderFactory.createLineBorder(gold));
			button[i].setFocusPainted(false);
			button[i].addMouseListener(this);
			button[i].addActionListener(this);
		}
		rgstrbtn.setBackground(gold);
		bckbtn.setBackground(fieldcolor);
		bckbtn.setForeground(navy);
		bckbtn.setBorder(BorderFactory.createLineBorder(navy));
		exitbtn.setBackground(fieldcolor);
		exitbtn.setForeground(navy);
		img=new ImageIcon("./Images/pr2.jpeg");
		Image image=img.getImage().getScaledInstance(900,550,Image.SCALE_SMOOTH);
		imglbl=new JLabel(new ImageIcon(image));
		imglbl.setBounds(0,0,900,550);
		panel.add(imglbl);
		this.add(panel);
	}
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me)
	{
		JButton button=(JButton)me.getSource();
		button.setBackground(navy);
		button.setForeground(Color.WHITE);
	}
	public void mouseReleased(MouseEvent me)
	{
		mouseEntered(me);
	}
	public void mouseEntered(MouseEvent me)
	{
		JButton button=(JButton)me.getSource();
		button.setBackground(new Color(235,178,55));
		button.setForeground(navy);
	}
	public void mouseExited(MouseEvent me)
	{
		JButton button=(JButton)me.getSource();
		if(button==rgstrbtn)
		{
			button.setBackground(gold);
			button.setForeground(Color.WHITE);
		}
		else
		{
			button.setBackground(fieldcolor);
			button.setForeground(navy);
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		String s1=namfld.getText();
		String s2=passfld.getText();
		String s3=repeatfld.getText();
		String role=rolebox.getSelectedItem().toString();
		if(ae.getSource()==rgstrbtn)
		{
			if(s1.isEmpty()||s2.isEmpty()||s3.isEmpty())
			{
				JOptionPane.showMessageDialog(this,"Fill up All");
			}
			else if(s2.equals(s3)==false)
			{
				JOptionPane.showMessageDialog(this,"Password Does Not Match");
			}
			else
			{
				Account a1=new Account(s1,s2);
				if(role.equals("Admin"))
				{
					a1.addAdmin();
				}
				else
				{
					a1.addAccount();
				}
				JOptionPane.showMessageDialog(this,"Registration Successful");
				this.setVisible(false);
				Login f1=new Login();
				f1.setVisible(true);
			}
		}
		else if(ae.getSource()==bckbtn)
		{
			this.setVisible(false);
			Login f1=new Login();
			f1.setVisible(true);
		}
		else if(ae.getSource()==exitbtn)
		{
			System.exit(0);
		}
	}
}
