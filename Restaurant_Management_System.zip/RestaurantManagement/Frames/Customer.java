package Frames;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;
import Entities.MenuItem;
public class Customer extends JFrame implements MouseListener,ActionListener
{
	private JPanel panel,formpanel,listpanel;
	private JLabel titlelbl,userlbl,imglbl;
	private JTextField namefld,phonefld,quantityfld,pricefld,searchfld;
	private JComboBox tablebox,timebox,employeebox,itembox;
	private JTextArea orderarea;
	private JScrollPane scroll;
	private JButton addbtn,updatebtn,deletebtn,clearbtn,savebtn,bckbtn,searchbtn;
	private Login f1;
	private String vr;
	private boolean fromadmin;
	private Order order[]=new Order[200];
	private String employee[]=new String[100];
	private String menuitem[]=new String[100];
	private String table[]=new String[100];
	private int total,employeetotal,menuitemtotal,tabletotal;
	private int nextid=1;
	private int selected=-1;
	private int searchresult=-1;
	private Color navy,gold,cream;
	private ImageIcon img;
	public Customer(String vr,Login f1)
	{
		this(vr,f1,false);
	}
	public Customer(String vr,Login f1,boolean fromadmin)
	{
		super("Restaurant Customer Order Panel");
		this.setSize(1080,620);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.vr=vr;
		this.f1=f1;
		this.fromadmin=fromadmin;
		navy=new Color(16,45,82);
		gold=new Color(220,166,49);
		cream=new Color(255,253,247);
		loadData();
		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(250,246,235));
		if(fromadmin==true)
		{
			titlelbl=new JLabel("Order Management");
		}
		else
		{
			titlelbl=new JLabel("Customer Order Panel");
		}
		titlelbl.setBounds(300,12,480,42);
		titlelbl.setFont(new Font("Cambria",Font.BOLD,28));
		titlelbl.setForeground(navy);
		titlelbl.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(titlelbl);
		userlbl=new JLabel("User: "+vr);
		userlbl.setBounds(815,18,220,30);
		userlbl.setFont(new Font("Cambria",Font.PLAIN,17));
		userlbl.setForeground(navy);
		userlbl.setHorizontalAlignment(SwingConstants.RIGHT);
		panel.add(userlbl);
		formpanel=new JPanel();
		formpanel.setLayout(null);
		formpanel.setBounds(20,65,445,485);
		formpanel.setBackground(cream);
		formpanel.setBorder(BorderFactory.createLineBorder(gold));
		panel.add(formpanel);
		JLabel formlbl=new JLabel("Order Information");
		formlbl.setBounds(20,10,400,28);
		formlbl.setFont(new Font("Cambria",Font.BOLD,19));
		formlbl.setForeground(navy);
		formpanel.add(formlbl);
		namefld=makeField(formpanel,"Customer Name",20,45);
		phonefld=makeField(formpanel,"Phone",230,45);
		tablebox=makeCombo(formpanel,"Table Number",table,tabletotal,20,110);
		String time[]={"12:00 PM","02:00 PM","06:00 PM","07:00 PM","08:00 PM","09:00 PM"};
		timebox=makeCombo(formpanel,"Order Time",time,time.length,230,110);
		timebox.setSelectedItem("07:00 PM");
		employeebox=makeCombo(formpanel,"Employee / Staff",employee,employeetotal,20,175);
		String item[]=new String[menuitemtotal];
		for(int i=0;i<menuitemtotal;i++)
		{
			String value[]=menuitem[i].split("\t");
			if(value.length==2)
				item[i]=value[0];
		}
		itembox=makeCombo(formpanel,"Menu Item",item,item.length,230,175);
		quantityfld=makeField(formpanel,"Quantity",20,240);
		pricefld=makeField(formpanel,"Unit Price",230,240);
		pricefld.setEditable(false);
		searchfld=makeField(formpanel,"Search ID, Name, Table or Item",20,305);
		searchfld.setBounds(20,326,275,30);
		searchbtn=makeButton(formpanel,"Search",315,326,110);
		addbtn=makeButton(formpanel,"Add",20,380,120);
		updatebtn=makeButton(formpanel,"Update",162,380,120);
		deletebtn=makeButton(formpanel,"Delete",304,380,120);
		clearbtn=makeButton(formpanel,"Clear",20,430,120);
		savebtn=makeButton(formpanel,"Save",162,430,120);
		bckbtn=makeButton(formpanel,"Back",304,430,120);
		listpanel=new JPanel();
		listpanel.setLayout(null);
		listpanel.setBounds(485,65,555,485);
		listpanel.setBackground(cream);
		listpanel.setBorder(BorderFactory.createLineBorder(gold));
		panel.add(listpanel);
		JLabel listlbl=new JLabel("Saved Orders");
		listlbl.setBounds(20,12,500,30);
		listlbl.setFont(new Font("Cambria",Font.BOLD,19));
		listlbl.setForeground(navy);
		listpanel.add(listlbl);
		orderarea=new JTextArea();
		orderarea.setFont(new Font("Monospaced",Font.PLAIN,14));
		orderarea.setForeground(navy);
		orderarea.setBackground(cream);
		orderarea.setEditable(false);
		orderarea.addMouseListener(this);
		scroll=new JScrollPane(orderarea);
		scroll.setBounds(20,50,515,415);
		scroll.setBorder(BorderFactory.createLineBorder(gold));
		listpanel.add(scroll);
		itembox.addActionListener(this);
		showPrice();
		showOrder();
		img=new ImageIcon("./Images/pr2.jpeg");
		Image image=img.getImage().getScaledInstance(1080,620,Image.SCALE_SMOOTH);
		imglbl=new JLabel(new ImageIcon(image));
		imglbl.setBounds(0,0,1080,620);
		panel.add(imglbl);
		this.add(panel);
	}
	private JTextField makeField(JPanel value,String text,int x,int y)
	{
		JLabel label=new JLabel(text);
		label.setBounds(x,y,200,18);
		label.setFont(new Font("Cambria",Font.BOLD,13));
		label.setForeground(navy);
		value.add(label);
		JTextField field=new JTextField();
		field.setBounds(x,y+21,195,30);
		field.setFont(new Font("Cambria",Font.PLAIN,14));
		field.setBackground(cream);
		field.setBorder(BorderFactory.createLineBorder(gold));
		value.add(field);
		return field;
	}
	private JComboBox makeCombo(JPanel value,String text,String data[],int total,int x,int y)
	{
		JLabel label=new JLabel(text);
		label.setBounds(x,y,200,18);
		label.setFont(new Font("Cambria",Font.BOLD,13));
		label.setForeground(navy);
		value.add(label);
		JComboBox combo=new JComboBox();
		combo.setBounds(x,y+21,195,30);
		combo.setFont(new Font("Cambria",Font.PLAIN,14));
		combo.setBackground(cream);
		combo.setBorder(BorderFactory.createLineBorder(gold));
		for(int i=0;i<total;i++)
			combo.addItem(data[i]);
		value.add(combo);
		return combo;
	}
	private JButton makeButton(JPanel value,String text,int x,int y,int width)
	{
		JButton button=new JButton(text);
		button.setBounds(x,y,width,34);
		button.setFont(new Font("Cambria",Font.BOLD,14));
		button.setFocusPainted(false);
		button.addMouseListener(this);
		button.addActionListener(this);
		normalButton(button);
		value.add(button);
		return button;
	}
	private void normalButton(JButton button)
	{
		String text=button.getText();
		button.setBackground(navy);
		button.setForeground(Color.WHITE);
		button.setBorder(BorderFactory.createLineBorder(navy));
		if(text.equals("Add")||text.equals("Save"))
		{
			button.setBackground(gold);
			button.setBorder(BorderFactory.createLineBorder(gold));
		}
		else if(text.equals("Clear")||text.equals("Back"))
		{
			button.setBackground(cream);
			button.setForeground(navy);
		}
	}
	private void loadData()
	{
		Employee e1=new Employee();
		employeetotal=e1.getEmployee(employee);
		MenuItem m1=new MenuItem();
		menuitemtotal=m1.getMenuItem(menuitem);
		Table t1=new Table();
		tabletotal=t1.getTable(table);
		Order o1=new Order();
		total=o1.getOrder(order);
		for(int i=0;i<total;i++)
		{
			try
			{
				int id=Integer.parseInt(order[i].getOid());
				if(id>=nextid)
					nextid=id+1;
			}
			catch(Exception e)
			{
			}
		}
	}
	private String getPrice(String item)
	{
		String price="0";
		for(int i=0;i<menuitemtotal;i++)
		{
			String value[]=menuitem[i].split("\t");
			if(value.length==2&&value[0].equals(item))
				price=value[1];
		}
		return price;
	}
	private void showPrice()
	{
		pricefld.setText("");
		if(itembox.getSelectedItem()!=null)
			pricefld.setText(getPrice(itembox.getSelectedItem().toString()));
	}
	private Order getForm(String id)
	{
		String name=namefld.getText().trim();
		String phone=phonefld.getText().trim();
		String quantity=quantityfld.getText().trim();
		if(name.isEmpty()||phone.isEmpty()||quantity.isEmpty())
		{
			JOptionPane.showMessageDialog(this,"Fill up Customer Name, Phone and Quantity");
			return null;
		}
		else if(tablebox.getSelectedItem()==null||employeebox.getSelectedItem()==null||itembox.getSelectedItem()==null)
		{
			JOptionPane.showMessageDialog(this,"Employee, Menu Item and Table data are required");
			return null;
		}
		try
		{
			int q=Integer.parseInt(quantity);
			if(q<=0)
			{
				JOptionPane.showMessageDialog(this,"Quantity must be a positive number");
				return null;
			}
			String item=itembox.getSelectedItem().toString();
			String price=getPrice(item);
			double p=Double.parseDouble(price);
			String itemtotal=String.format("%.2f",p*q);
			OrderItem o1=new OrderItem(item,quantity,price,itemtotal);
			Order o2=new Order(id,name,phone,tablebox.getSelectedItem().toString(),timebox.getSelectedItem().toString(),employeebox.getSelectedItem().toString(),o1);
			return o2;
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this,"Quantity or Menu Price is not valid");
			return null;
		}
	}
	private void addOrder()
	{
		if(total>=200)
		{
			JOptionPane.showMessageDialog(this,"Order limit reached");
			return;
		}
		Order o1=getForm(String.valueOf(nextid));
		if(o1==null)
			return;
		order[total]=o1;
		total++;
		nextid++;
		o1.addOrder();
		clearField();
		JOptionPane.showMessageDialog(this,"Order Added");
	}
	private void updateOrder()
	{
		if(selected<0)
		{
			JOptionPane.showMessageDialog(this,"Click an order first");
			return;
		}
		Order o1=getForm(order[selected].getOid());
		if(o1==null)
			return;
		order[selected]=o1;
		Order o2=new Order();
		o2.saveOrder(order,total);
		clearField();
		JOptionPane.showMessageDialog(this,"Order Updated");
	}
	private void deleteOrder()
	{
		if(selected<0)
		{
			JOptionPane.showMessageDialog(this,"Click an order first");
			return;
		}
		for(int i=selected;i<total-1;i++)
		{
			order[i]=order[i+1];
		}
		total--;
		order[total]=null;
		Order o1=new Order();
		o1.saveOrder(order,total);
		clearField();
		JOptionPane.showMessageDialog(this,"Order Deleted");
	}
	private void clearField()
	{
		namefld.setText("");
		phonefld.setText("");
		quantityfld.setText("");
		searchfld.setText("");
		if(tablebox.getItemCount()>0)
			tablebox.setSelectedIndex(0);
		timebox.setSelectedItem("07:00 PM");
		if(employeebox.getItemCount()>0)
			employeebox.setSelectedIndex(0);
		if(itembox.getItemCount()>0)
			itembox.setSelectedIndex(0);
		selected=-1;
		searchresult=-1;
		showPrice();
		showOrder();
	}
	private void searchOrder()
	{
		String key=searchfld.getText().trim().toLowerCase();
		boolean flag=false;
		if(key.isEmpty())
		{
			JOptionPane.showMessageDialog(this,"Enter Order ID, Customer Name, Table or Menu Item");
			return;
		}
		for(int i=0;i<total;i++)
		{
			String id=order[i].getOid().toLowerCase();
			String name=order[i].getCname().toLowerCase();
			String tableno=order[i].getTnumber().toLowerCase();
			String item=order[i].getOitem().getIname().toLowerCase();
			if(id.equals(key)||name.contains(key)||tableno.contains(key)||item.contains(key))
			{
				selected=i;
				searchresult=i;
				loadForm(order[i]);
				orderarea.setText(getLine(order[i]));
				flag=true;
				break;
			}
		}
		if(flag==false)
		{
			searchresult=-1;
			showOrder();
			JOptionPane.showMessageDialog(this,"Order Not Found");
		}
	}
	private void loadForm(Order o1)
	{
		namefld.setText(o1.getCname());
		phonefld.setText(o1.getPhone());
		tablebox.setSelectedItem(o1.getTnumber());
		timebox.setSelectedItem(o1.getOtime());
		employeebox.setSelectedItem(o1.getEname());
		itembox.setSelectedItem(o1.getOitem().getIname());
		quantityfld.setText(o1.getOitem().getIquantity());
		pricefld.setText(o1.getOitem().getIprice());
	}
	private String getLine(Order o1)
	{
		String line=o1.getOid()+" | "+o1.getCname()+" | ";
		line=line+o1.getOitem().getIname()+" x"+o1.getOitem().getIquantity()+" | ";
		line=line+o1.getTnumber()+" | Total: "+o1.getOitem().getItotal()+"\n";
		return line;
	}
	private void showOrder()
	{
		searchresult=-1;
		String text="";
		if(total==0)
			text="No orders saved yet.\n";
		for(int i=0;i<total;i++)
			text=text+getLine(order[i]);
		orderarea.setText(text);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==addbtn)
			addOrder();
		else if(ae.getSource()==updatebtn)
			updateOrder();
		else if(ae.getSource()==deletebtn)
			deleteOrder();
		else if(ae.getSource()==clearbtn)
			clearField();
		else if(ae.getSource()==savebtn)
		{
			Order o1=new Order();
			o1.saveOrder(order,total);
			JOptionPane.showMessageDialog(this,"Order Data Saved");
		}
		else if(ae.getSource()==searchbtn)
			searchOrder();
		else if(ae.getSource()==itembox)
			showPrice();
		else if(ae.getSource()==bckbtn)
		{
			this.setVisible(false);
			if(fromadmin==true)
			{
				Admin a1=new Admin(vr,f1);
				a1.setVisible(true);
			}
			else
			{
				Homepage h1=new Homepage(vr,f1);
				h1.setVisible(true);
			}
		}
	}
	public void mouseClicked(MouseEvent me)
	{
		if(me.getSource()!=orderarea)
			return;
		if(searchresult>=0)
		{
			selected=searchresult;
			loadForm(order[selected]);
			return;
		}
		try
		{
			int line=orderarea.getLineOfOffset(orderarea.getCaretPosition());
			if(line<total)
			{
				selected=line;
				loadForm(order[selected]);
			}
		}
		catch(Exception e)
		{
		}
	}
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource() instanceof JButton)
		{
			JButton button=(JButton)me.getSource();
			button.setBackground(new Color(235,178,55));
			button.setForeground(navy);
		}
	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource() instanceof JButton)
			normalButton((JButton)me.getSource());
	}
	public void mousePressed(MouseEvent me)
	{
		if(me.getSource() instanceof JButton)
		{
			JButton button=(JButton)me.getSource();
			button.setBackground(navy);
			button.setForeground(Color.WHITE);
		}
	}
	public void mouseReleased(MouseEvent me)
	{
		mouseEntered(me);
	}
}
